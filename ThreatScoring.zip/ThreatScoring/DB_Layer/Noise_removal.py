import sys
import csv
import itertools
import MySQLdb
from passlib.hash import pbkdf2_sha256
import pandas as pd
import os
import CTI.DB_Layer.Obs as Obs
#import Obs
from datetime import datetime
class RemoveJob():

	def __init__(self):
		self.folder_dir=os.path.dirname(os.path.realpath(__file__))

	def close_connection(self):
		try:
			if self.conn.open:
				self.conn.close()
		except Exception as ee:
			print("Exception occured while closing connection : "+str(ee))
	
	def init_connection(self):
		try:		
			user=''
			password=''
			host=''
			db=''
			self.folder_dir=os.path.dirname(os.path.realpath(__file__))
			try:				
				db_file=os.path.join(self.folder_dir,"db_file.txt")
				with open(db_file ,"r+") as db:	
					user_pass=db.read()
					user_pass=user_pass.replace("\n","").replace("\r\n","").replace("\r","")
					user_pass=user_pass.split("**##**")
					user=user_pass[0]
					password=Obs.decode(str(user_pass[1]))
					if type(password)!=type(str):
						password=password.decode("utf-8") 
					
					#print ("\n\nPassword is : "+str(password))
					host=user_pass[2]
					db=user_pass[3]
					
			except Exception as eex:
				print("Exception occured while Reading DB file : "+str(eex))

			self.conn=MySQLdb.connect(host,user,password,db)
			self.cursor = self.conn.cursor()
			self.cur=self.conn.cursor()

		except Exception as ee:
			print(str(ee))
			print("Exception occured in connection : "+str(ee))

	def remove(self,del_list):
		try:
			format_strings=','.join(['%s'] * len(del_list))
			sql_query="delete from attributes where value1 in (%s)" % format_strings
			sql_query2="delete from threat_scoring where value in (%s)" % format_strings
			self.cur.execute(sql_query,tuple(del_list))
			self.conn.commit()
			self.log_message("Removed :"+str(self.cur.row_count))
			#self.cur.execute(sql_query2,tuple(del_list))
			#print("Del 2: " +str(self.cur.rowcount))
			#self.conn.commit()
			#print("\n\n")
		except Exception as ex:
			self.log_message("Exception caught while removing:")

	def log_message(self,message):
		try:
			log_file_path=os.path.join(self.folder_dir,"Logs")
			log_file=os.path.join(log_file_path,"Log_"+str(datetime.now().date()))
			with open(log_file,"a") as l_file:
				l_file.write(message)
		except Exception as ex:
			print("Exception : " +str(ex))

	def RemoveNoise(self):
		try:
			
			self.log_message("Started : " +str(datetime.now()))
			ret_resp={}
			chunksize = 100000
			
			dtype={"GlobalRank":str,"TldRank":str,"Domain":str,"TLD":str,"RefSubNets":str,"RefIPs":str,"IDN_Domain":str,"IDN_TLD":str,"PrevGlobalRank":str,"PrevTldRank":str,"PrevRefSubNets":str,"PrevRefIPs":str}
			file_=os.path.join(self.folder_dir,"million.csv")
			reader=0
			for chunk in pd.read_csv(file_, chunksize=chunksize,iterator=True,dtype=dtype,encoding='latin-1'):
				
				#if reader == 1 :
				#	break 
				chunk = chunk.rename(columns={c: c.replace(' ', '_').replace("\n","").replace("\r","") for c in chunk.columns})

				

				del_list=[]
			
				for i,c in chunk.iterrows():
					in_checker="www."+str(c.IDN_Domain)
				
					del_list.append(in_checker)
					del_list.append(str(c.IDN_Domain))

				for i in range(0,len(del_list),10000):
					self.init_connection()
					self.remove(del_list[i:i+10000])
					self.close_connection()

				
			
			
			self.log_message("Ended : " +str(datetime.now()))
			reader=reader+1
			
		except Exception as ex:
			self.log_message("Exception Caught in Removing Noise : " +str(ex))
			self.conn.rollback()
			self.close_connection()
			


#obj=RemoveJob()
#obj.RemoveNoise()



"""
Removed Noise :

476
276
197

Del 1 : 88



Del 1 : 131



Del 1 : 112



Del 1 : 135



Del 1 : 175



Del 1 : 109



Del 1 : 115



Del 1 : 127



Del 1 : 124



Del 1 : 142

Del 1 : 122



Del 1 : 127



Del 1 : 142



Del 1 : 100



Del 1 : 196



Del 1 : 127



Del 1 : 137



Del 1 : 141



Del 1 : 88



Del 1 : 110



Del 1 : 139



Del 1 : 111



Del 1 : 113



Del 1 : 104



Del 1 : 93



Del 1 : 103



Del 1 : 136



Del 1 : 88



Del 1 : 68



Del 1 : 73

Del 1 : 86



Del 1 : 66



Del 1 : 52



Del 1 : 65



Del 1 : 86



Del 1 : 74



Del 1 : 79



Del 1 : 81



Del 1 : 105



Del 1 : 97



Del 1 : 99



Del 1 : 92



Del 1 : 63



Del 1 : 89



Del 1 : 100



Del 1 : 98



Del 1 : 93



Del 1 : 63



Del 1 : 43



Del 1 : 44



Del 1 : 41



Del 1 : 45



Del 1 : 38



Del 1 : 35



Del 1 : 58



Del 1 : 45



Del 1 : 34



Del 1 : 32



Del 1 : 44



Del 1 : 56



Del 1 : 32



Del 1 : 39



Del 1 : 31



Del 1 : 51



Del 1 : 56



Del 1 : 25



Del 1 : 43



Del 1 : 52

Del 1 : 52



Del 1 : 39



Del 1 : 29

Del 1 : 40



Del 1 : 43



Del 1 : 35



Del 1 : 32



Del 1 : 49



Del 1 : 28



Del 1 : 52



Del 1 : 35



Del 1 : 48



Del 1 : 26



Del 1 : 46



Del 1 : 24



Del 1 : 31



Del 1 : 41



Del 1 : 37



Del 1 : 58



Del 1 : 26



Del 1 : 25



Del 1 : 20



Del 1 : 19



Del 1 : 30



Del 1 : 21



Del 1 : 37



Del 1 : 22



Del 1 : 21



Del 1 : 25



Del 1 : 42



Del 1 : 28



Del 1 : 33



Del 1 : 37



Del 1 : 33



Del 1 : 31



Del 1 : 31



Del 1 : 26



Del 1 : 30



Del 1 : 17



Del 1 : 28



Del 1 : 29



Del 1 : 11



Del 1 : 25

Del 1 : 36



Del 1 : 27



Del 1 : 36



Del 1 : 24



Del 1 : 28



Del 1 : 29



Del 1 : 33



Del 1 : 28



Del 1 : 12



Del 1 : 35



Del 1 : 23



Del 1 : 32



Del 1 : 21



Del 1 : 29



Del 1 : 22



Del 1 : 24



Del 1 : 25



Del 1 : 28



Del 1 : 33



Del 1 : 35



Del 1 : 31



Del 1 : 41



Del 1 : 35



Del 1 : 25



Del 1 : 30



Del 1 : 19



Del 1 : 12



Del 1 : 17



Del 1 : 41



Del 1 : 33



Del 1 : 12



Del 1 : 24



Del 1 : 16



Del 1 : 29



Del 1 : 29



Del 1 : 29



Del 1 : 39



Del 1 : 29



Del 1 : 27



Del 1 : 29



Del 1 : 33



Del 1 : 34



Del 1 : 23



Del 1 : 37



Del 1 : 30



Del 1 : 20



Del 1 : 25



Del 1 : 22



Del 1 : 29



Del 1 : 45



Del 1 : 25



Del 1 : 36



Del 1 : 31



Del 1 : 16



Del 1 : 35



Del 1 : 39



Del 1 : 27



Del 1 : 27



Del 1 : 34



Del 1 : 34



Del 1 : 20



Del 1 : 18



Del 1 : 36



Del 1 : 26



Del 1 : 22



Del 1 : 21



Del 1 : 28



Del 1 : 18



Del 1 : 17



Del 1 : 23



Del 1 : 25



Del 1 : 22



Del 1 : 26



Del 1 : 14



Del 1 : 29



Del 1 : 12



Del 1 : 23



Del 1 : 23



Del 1 : 27



Del 1 : 32





"""
