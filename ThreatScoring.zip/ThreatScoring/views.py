"""
@Author		:Furqan Khan
@Email		:furqan.khan@du.ae
@Date 		:05/02/2018
Objective :
The purpose of this file /module /Class is to map to serve teh Rest request
Depending upon the requested url the views module will fetch the data from the backend
python files and would transform the data to json format ,and would finally return the data back to the
requesting application.
"""
from django.utils import timezone
import pytz
from django.shortcuts import render
from CTI.serializers import *
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.renderers import JSONRenderer
from rest_framework.parsers import JSONParser,MultiPartParser,FormParser,FileUploadParser
from rest_framework import status
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt,csrf_protect
from django.views.decorators.csrf import ensure_csrf_cookie
from django.utils.decorators import method_decorator
from wsgiref.util import FileWrapper
import json
import os
from CTI.models import *
from django.core import serializers
from CTI.keys import misp_url, misp_key
from CTI.App_and_Api.views import Custom
import logging
from CTI.DB_Layer.Misp_access import MispDB
import multiprocessing
import math
from CTI.tasks import Update_th_score
from django_celery_beat.models import CrontabSchedule, PeriodicTask ,IntervalSchedule
import datetime
import time
from datetime import timedelta

      
class ThreatScoring(APIView):

	def post(self,request,schedule=0,parllel=0,format=None):
		return_response={}
		try:	
			task_name="Threat Scoring"
			#print(type(schedule))
			#print(schedule)
			if int(schedule) == 1:
				#print(request.data)
				ts=ThreatScoreSerializers(data=request.data)
				#print(str(ts))
				if ts.is_valid():
					every=int(ts.data["every"])
					#if int(every) < 12:
					#	every=12
					#date=ts.data["date"]
					#actual_time=str(ts.data["time"])
					#time_hours=str(ts.data["time"]).split(":")
					#hours=time_hours[0]
					#minutes=time_hours[1]
					#time_format = '%Y-%m-%d'
					#date_delta= datetime.datetime.strptime(date, time_format)
					#dom=date_delta.day
					#moy=date_delta.month
					ptask_name = "%s_%s" % (task_name, datetime.datetime.now())
					task_process=MispDB().getTaskid("threat_scoring")
					if task_process["status"]=="success":
						process_id=task_process["process_id"]
						task_id=task_process["task_id"]
						parent_process=None
						if process_id:
							try:
								parent_process=PeriodicTask.objects.get(id=process_id)
								
							except Exception as ex:
								print("Ex 1:"+str(process_id) +str(ex))
								pass
						task_st=MispDB().createTask(status="pre-init",task_message="Scoring task scheduled",is_current=True)
						if task_st["status"]=="success":
							task_idd=task_st["value"]
						else:
							
							return_response["status"]="failure"
							return_response["value"]="Cant create entry in child task"+str(task_st["value"])
							return Response(JSONRenderer().render(return_response))
							
						if parent_process:
								
								schedule, _=IntervalSchedule.objects.get_or_create(every=every,period=IntervalSchedule.HOURS)
								
								parent_process.interval=schedule
								parent_process.args=json.dumps(["parllel",task_idd])
								parent_process.task='Update_th_score'
								
								
								
								if request.data.get("reset",0):
									print("Reset is set")
									dt_=timezone.now()
									hr=dt_.hour
									hr=hr-4
									#print(dt_)
									#print(hr)
									dt_-= datetime.timedelta(hours=int(hr))  # as it automatically converts it into utc
									#print(dt_)
									parent_process.last_run_at=None
									#PeriodicTask.objects.update(last_run_at=None)
									#print("Reached here")
								
								parent_process.save()
								try:
									last_run=parent_process.last_run_at
									
									if last_run == None:
										last_run=parent_process.date_changed
									#last_run+=datetime.timedelta(hours=4) #UTF and dubai time diff
									#No need to change the time 
									#Lets use UTC for comparison
									lt=last_run.time()
									last_run_time=datetime.timedelta(hours=int(lt.hour),minutes=lt.minute,seconds=lt.second)
									interval_time=datetime.timedelta(hours=int(every),minutes=0,seconds=0)
									next_time=last_run_time+interval_time
									if next_time.days > 0:
										time_only=str(next_time).split(',')[1].strip()
										time_sp=time_only.split(":")
										next_time=datetime.timedelta(hours=int(time_sp[0]),minutes=int(time_sp[1]),seconds=int(time_sp[2]))
										
								
									try:
										watcher,created=TaskWwatcher.objects.get_or_create(task_name="threat_scoring")
										watcher.to_be_exe_time=str(next_time)
										watcher.save()
									except Exception as ex:
										print("Watcher not found" +str(ex))
									
									
								except Exception as ex:
									print("@@ Exception : " +str(ex))
									pass
								#print("Saved")
								#print(parent_process.last_run_at)
						else:
								print("\n\n\nHere i am in else \n\n\n")
								schedule, _=IntervalSchedule.objects.get_or_create(every=every,period=IntervalSchedule.HOURS)
								parent_process=PeriodicTask.objects.create(interval=schedule,name=ptask_name,task='Update_th_score',args=json.dumps(["parllel",task_idd]),queue='CTI_quick_tasks')
								

						
											
						
							
						last_run=PeriodicTask.objects.filter(id=parent_process.id).values_list('last_run_at',flat=True)[0]
						if last_run == None or last_run == " " or last_run == "":
								last_run=str(datetime.datetime.now())[0:19]
						last_run=str(last_run)
						last_run=str(last_run[0:19])#2018-02-12 07:52:18.251207
						time_format = '%Y-%m-%d %H:%M:%S'
							
						date_delta= datetime.datetime.strptime(last_run, time_format)
							
						date_delta+= datetime.timedelta(hours=int(every))
							
						sc_tm=str(date_delta)[11:19]
						date_delta=int(time.mktime(date_delta.timetuple()))
							
						update_stat=MispDB().updateSchedulerTask(id=task_id,timer=str(every),scheduled_time=str(sc_tm),next_execution_time=date_delta,process_id=parent_process.id)
							
						process_id=parent_process.id
						update_statt=MispDB().updateTask(task_id=task_idd,status="scheduled",message="Just scheduled and skeleton creating : - State : "+str("scheduling"),process_id=parent_process.id)
							

					
						if update_stat["status"]=="success":
							return_response["status"]="success"
							return_response["value"]={"task_id":task_id,"process_id":parent_process.id,"task_id_child":task_idd}
						
						else:
							return_response["status"]="warning"
							return_response["value"]={"task_id":task_id,"process_id":parent_process.id}
							return_response["warning"]="Cant Update the task status : "+str(update_stat["value"])
						
								
					else:
						return_response["status"]="failure"
						return_response["value"]="Cant create task !" +str(task_process["value"])
						return_response["error"]="Cant create task !" +str(task_process["value"])
						
				else:
					return_response["status"]="failure"
					return_response["value"]="Invalid details POSTED !" +str(ts.errors)
					return_response["error"]="Cant pull task !" +str(ts.errors)
			
						
							
				
				return Response(JSONRenderer().render(return_response))
			else:
				print("In else !!! @ Simple pull")
				task_st=MispDB().createTask(status="init",task_message="Scoring Task Started")
				if task_st["status"]=="success":
					task_id=task_st["value"]
					parent_process=Update_th_score.delay(mode="parllel",task_id=task_id)
					#parent_process=Update_th_score.apply_async(('CTI/QualysNessus/Files/Qualys_Public.csv',),queue='CTI_report_tasks')

					
					update_stat=MispDB().updateTask(task_id=task_id,status="started",message="Process Created - State : "+str(parent_process.state),process_id=parent_process.id)
					if update_stat["status"]=="success":
						return_response["status"]="success"
						return_response["value"]={"task_id":task_id,"process_id":parent_process.id}
					else:
						return_response["status"]="warning"
						return_response["value"]={"task_id":task_id,"process_id":parent_process.id}
						return_response["warning"]="CANT Update the task status : "+str(update_stat["value"])
						
				else:
					return_response["status"]="failure"
					return_response["value"]="Cant create task !" +str(task_st["value"])
					return_response["error"]="Cant create task !" +str(task_st["value"])
			
			return Response(JSONRenderer().render(return_response))

								
		except Exception as ex:
				return_response["status"]="failure"
				return_response["value"]="Exception : " +str(ex)
				return_response["error"]="Exception : " +str(ex)
				return Response(JSONRenderer().render(return_response))

	
	
			


	






		



		
			











		
				
