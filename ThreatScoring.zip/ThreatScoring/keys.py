#!/usr/bin/env python
# -*- coding: utf-8 -*-

misp_url = 'http://127.0.0.1/'
#misp_key = '09Vj1jRa0v6SphEoCo4uFw4XXTbYpGbXEQUxuC8b'
misp_key = '0O4Nt6Cjgk9nkPdVennsA6axsYIgdRvf2FQYY5lx'
#The MISP auth key can be found on the MISP web interface under the automation section .Later on automate this to pull the admin key from 
#the database always ,the misp_key is requested.Change the logic in Custom class of views
misp_verifycert = False
