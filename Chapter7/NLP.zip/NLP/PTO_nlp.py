# Natural Language Processing

# Importing the libraries
import numpy as np
from numpy import *
import matplotlib.pyplot as plt
import pandas as pd
import re
import nltk
#nltk.download('stopwords')
from nltk.corpus import stopwords
from nltk.stem.porter import PorterStemmer
from sklearn.cross_validation import train_test_split
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import confusion_matrix
import NLP_db
import pickle
class PreProcessor():
	def preprocess(self,project_id,report_name="tsv_results.tsv"):
		self.services=[]
		with open ("nlp_services.txt","r") as infile:
			services=infile.readlines()
		for line in services:
			self.services.append(line.replace('\n','').replace('\r',''))
		print (str(self.services))
		obj=NLP_db.IPexploits()
		results=obj.getResults(project_id,self.services)
		if results["status"]=="success":
			result_data=results["value"][0]["value"]
			tsv_file=[]
			if report_name=="tsv_results.tsv":
				tsv_file.append("cid\t" +"rid\t"+"service\t"+"result\t"+"vul"+"\n")
			else:
				tsv_file.append("cid\t" +"rid\t"+"service\t"+"result"+"\n")
			csv_file=[]
			for data in result_data	:
				print (str(data["id"])+"  " +str(data["service"]))
				for k,v in data["exploits"].items():
					for kk,vv in v.items():

						print (str(kk) +"  " +str(str(vv[2]).split("Result",1)[-1]))
						command_id=str(kk)
						result_data=str(str(vv[2]).split("Result",1)[-1])
						record_id=data["id"]
						service=data["service"]
						result_data=result_data.replace("\r","").replace("\r\n","").replace("\n"," ").replace("run","")
						result_data=re.sub(r'[^a-zA-Z0-9^\x00-\x7f.()@"\-\s[]<>]',' ',result_data)
						result_data=result_data.replace("[0;35m","").replace("[m","").replace("[m[1;32m","").replace("","").replace("[m","").replace("[1;32m"," ").replace("[1;","").replace("[1m","").replace("###########################################################","").replace("<<-- <class 'pexpect.exceptions.EOF'>End of file -","")
						result_data=' '.join(result_data.split())
						tsv_file.append(command_id +"\t" +record_id+"\t"+service+"\t"+result_data+"\n")
						csv_file.append(command_id +"," +record_id+","+service+","+result_data+",")
			with open(report_name,"w+") as ofile:
				ofile.writelines(tsv_file)
				print ("Results written")
			
						
		else:
			print ("Exception : "+str(results))
		#print (str(results))
			
		#print (str(self.services))
pre=PreProcessor()
#pre.preprocess(720)

class NLP_PTO():
	def Train_test_machine(self):
		# Importing the dataset
		dataset = pd.read_csv('tsv_results.tsv', delimiter = '\t', quoting = 3)
		print (len(dataset))
		# Cleaning the texts

		corpus = []
		for i in range(0, 182):
			review = re.sub('\d{1,3}.\d{1,3}.\d{1,3}.\d{1,3}', ' ', dataset['result'][i])
			review = re.sub(':\d{1,5}', ' ', dataset['result'][i])
			review = review.lower()
			review = review.split()
			ps = PorterStemmer()
			#print (str(stopwords.words('english')))
			#print("\n\n")
			review = [ps.stem(word) for word in review if not word in set(stopwords.words('english'))]
			review = ' '.join(review)
			corpus.append(review)

		# Creating the Bag of Words model

		cv = CountVectorizer(max_features = 5000)
		X = cv.fit_transform(corpus).toarray()
		y = dataset.iloc[:, 4].values
		print ("X length :"+str(len(X)))
		print (str(X))
		#print (str(corpus))
		print("\n\n\n")

		# Splitting the dataset into the Training set and Test set

		X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.20, random_state = 0)

		# Fitting Naive Bayes to the Training set
		print (str(X_train))
		where_are_NaNs = isnan(y_train)
		y_train[where_are_NaNs] = 0
		print (np.isnan(X_train).any(), np.isnan(X_test).any(), np.isnan(y_train).any(),np.isnan(y_test).any())
		classifier = GaussianNB()
		classifier.fit(X_train, y_train)
		filename = 'Trained_model.sav'
		pickle.dump(classifier, open(filename, 'wb'))
		pickle.dump(cv, open("saved_vector.sav", 'wb'))
 

		# Predicting the Test set results
		y_pred = classifier.predict(X_test)

		# Making the Confusion Matrix

		cm = confusion_matrix(y_test, y_pred)
		print (str(cm))
		result=classifier.score(X_test,y_test)
		print (result)
		print ("Now reloading saved model !!")
		classifier = pickle.load(open("Trained_model.sav", 'rb'))
		y_pred = classifier.predict(X_test)
		print (str(y_pred))

	def Predict_results(self,project_id):
		pre=PreProcessor()
		pre.preprocess(project_id,"predict.tsv")
		dataset = pd.read_csv('predict.tsv', delimiter = '\t', quoting = 3)
		c_ids=dataset["cid"]
		r_ids=dataset["rid"]
		# Cleaning the texts

		corpus = []
		for i in range(0, len(dataset)):
			review = re.sub('\d{1,3}.\d{1,3}.\d{1,3}.\d{1,3}', ' ', dataset['result'][i])
			review = re.sub(':\d{1,5}', ' ', dataset['result'][i])
			review = review.lower()
			review = review.split()
			ps = PorterStemmer()
			#print (str(stopwords.words('english')))
			#print("\n\n")
			review = [ps.stem(word) for word in review if not word in set(stopwords.words('english'))]
			review = ' '.join(review)
			#print (review)
			#print("\n\n")
			corpus.append(review)

		# Creating the Bag of Words model
		#print (str(corpus))
		cv = pickle.load(open("saved_vector.sav", 'rb'))
		#X = cv.fit_transform(corpus).toarray()
		X = cv.transform(corpus).toarray()
		X_test=X
		#print (str(X_test))
		# some time later...
 
		# load the model from disk
		classifier = pickle.load(open("Trained_model.sav", 'rb'))
		y_pred = classifier.predict(X_test)
		for i in range (0,len(y_pred)):
			print (str(c_ids[i])+"  " +str(r_ids[i])+"  " +str(y_pred[i]))
			print("\n")
		#print (str(y_pred))
		#result = loaded_model.score(X_test, Y_test)

		
		
		
nlp=NLP_PTO()
#nlp.Train_test_machine()
nlp.Predict_results(719)
