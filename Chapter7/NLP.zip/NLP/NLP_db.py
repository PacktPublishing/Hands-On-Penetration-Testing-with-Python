"""
@Author		:Furqan Khan
@Email		:furqankhan08@gmail.com
@Date 		:1/2/2017

Objective :
The purpose of this file /module /Class is to call the backend database table IPexploits and pass the exploit details to it.It will save update ,delete and reterive details from IPexploits table and thus acts like a model class for the database table IPexploits
"""
import pymysql as MySQLdb
#import Auto_logger
import threading
import time
import ast
import json
import datetime
#from ansi2html import Ansi2HTMLConverter
#from ansi2html_ import ansi2html
import os 

class IPexploits:
	"""
		Objective :
		The purpose of this class is to pass the details to the backend IPexploits table .
		It acts like a model class which just communicates with the database layer
	"""
	def __init__(self,Pid=None,Host=None,Port=None,Service=None,Project_status=None,Exploits=None,service_status=None,Command_id=None):
		"""This is the init /Constructor of the given class"""		
		self.id=None
		self.Pid=Pid
		self.Host=Host
		self.Port=Port
		self.Service=Service
		self.Project_status=Project_status
		self.Exploits=Exploits
		self.Command_id=None
		self.service_status=service_status
		self.con=None
		self.cursor=None
		self.logger=None
		self.project_id="Default"
		self.lock = threading.Lock()
		#self.Auto_logger=Auto_logger.Logger()
		self.method_id="INIT"
		self.All_exploits=[]
		#self.conv = Ansi2HTMLConverter()
		self.data_path=""
		


	def init_connection(self):
		"""
			Objective :
			This method would initialise the database connection
		"""
		try:
			self.method_id="Init_connection()"
			self.folder_dir=os.path.dirname(os.path.realpath(__file__))
			user=''
			password=''
			try:
				db_file=os.path.join(self.folder_dir,"db_file.txt")
				with open(db_file ,"r+") as db:	
					user_pass=db.read()
					user_pass=user_pass.replace("\n","").replace("\r\n","").replace("\r","")
					user_pass=user_pass.split(":")
					user=user_pass[0]
					password=user_pass[1]
					
			except Exception as eex:
				print ("EXception ! " +str(eex))
				
			self.con=MySQLdb.connect("localhost",user,password,"nmapscan")
			self.cursor = self.con.cursor()
		except Exceptio as ee:
			self.print_Error("EXception in connection-->"+str(ee))

	def close_connection(self):
		"""
			Objective :
			This method would close the database connection
		"""
		try:
			self.method_id="Close_connection()"		
			if self.con.open:
				self.con.close()
		except Exception as ee:
			self.print_Error("EXception in connection-->"+str(ee))


				
		
	def getResults(self,project_id=0,service_list=[]):
		"""
		Objective :
		The purpose of this method is to reterive the details of commands executed ,services and the results
		for the current project id.This method aids in report generation by returning list of dictionaries 
		that contain mannual results for the current project id passed .
	
 		"""
		try:
			return_response={}
			return_data_list=[]
			self.init_connection()
			id_=int(project_id)
			format_strings=','.join(['%s'] * len(service_list)) #will convert to val like %s,%s,%s,%s ..
			self.init_connection()
			if 1:
				return_data={}
				data_list=[]
				#return_data["host"]=hosts[0]
				sql_q="select Id,Pid,Host,Port,Service,Exploits from IPexploits where service in (%s) and Pid=%%s and service_type='existing'"%format_strings
				args=service_list +[int(project_id)]
				self.cursor.execute(sql_q,args)
				#self.cursor.execute("select Id,Pid,Host,Port,Service,Exploits from IPexploits where Pid=%s and Host =%s and service_type='existing'",(id_,hosts[0]))
				report_data=self.cursor.fetchall()
				for record in report_data:
					report_content={}
					report_content["id"]=str(record[0])
					report_content["Pid"]=str(record[1])
					report_content["host"]=str(record[2])
					report_content["port"]=str(record[3])
					report_content["service"]=str(record[4])
					exploit_data={}
					exploit_data=record[5]
					if(isinstance(exploit_data,str)):
						#print "1"
						exploit_data=json.loads(exploit_data)
					report_content["exploits"]=exploit_data					
					data_list.append(report_content)

				return_data["value"]=data_list
				return_data_list.append(return_data)
			if (len(return_data_list)>0):
				return_response["status"]="success"
				return_response["value"]=return_data_list
			else:
				return_response["status"]="empty"
				return_response["value"]="0"

			self.close_connection()
			return return_response			
					
		except Exception as ex:
			print ("Exception caught while retuning_report" + str(ex))
			return_response["status"]="failure"
			return_response["value"]=str(ex)
			return_response["errors"]=str(ex)
			self.close_connection()
			return return_response

	

	def print_Log(self,message):
		"""
		Objective :
		The purpose of this method is to print the messages to the log file
 		"""
		
		#self.Log_file=str(self.project_id) +str("_Log_file_info")
		#self.logger=self.Auto_logger.configureLoggerInfo(self.method_id,self.Log_file)
		if 1:#self.logger is not None:
			print ("Message is : " +message+"\n")

	
		
	def print_Error(self,message):
		"""
		Objective :
		The purpose of this method is to print errors to the log file
 		"""
		print (message+"\n")



"""obj=IPexploits()
#print "started"
resp=obj.generate_report_GUI(246)
print str(resp)"""
		
